export const Universities = [
  {
    title: 'Lahore',
    image: '/assets/co1.png',
  },
  {
    title: 'Islamabad',
    image: '/assets/co2.png',
  },
  {
    title: 'Karachi',
    image: '/assets/co1.png',
  },

];
