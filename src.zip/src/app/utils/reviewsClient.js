// src/utils/reviews.js

const reviews = [
  {
    name: 'Kohlia Ramani',
    message: 'I recently sought help from Universes Page for Greece visa application, and I was thoroughly impressed...',
  },
  {
    name: 'Adnan Ahmed',
    message: 'I just wanted to take a moment to express my sincere gratitude for the invaluable assistance...',
  },
  {
    name: 'Ahmad Reza',
    message: 'I had a very good experience with Universes Page. The service was awesome...',
  },
];

export default reviews;
