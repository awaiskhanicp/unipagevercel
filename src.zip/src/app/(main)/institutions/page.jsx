// src/app/page.jsx

import UniversitiesPage from "../../components/organisms/UniversitiesPage";

export default function UniversitiesPages() {
  return (
    <main className="min-h-screen  bg-white">
      <UniversitiesPage />
    </main>
  );
}
