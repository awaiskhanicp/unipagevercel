// src/app/page.jsx

import CountriesGuide from "../../components/organisms/CountriesGuide";
export default function CountriesGuides() {
  return (
    <main className="min-h-screen  bg-white">
      <CountriesGuide />
    </main>
  );
}
