'use client';
import Layout from '../../components/Layout';
import InboxContact from '../../pages/Inbox/InboxContact';
export default function InboxContactPage() {
  return (
    <Layout>
      <InboxContact />
    </Layout>
  );
} 