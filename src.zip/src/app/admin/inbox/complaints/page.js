'use client';
import Layout from '../../components/Layout';
import InboxComplaints from '../../pages/Inbox/InboxComplaints';
export default function InboxComplaintsPage() {
  return (
    <Layout>
      <InboxComplaints />
    </Layout>
  );
} 