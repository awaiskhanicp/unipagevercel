'use client';

import UniversityCountries from '../../../admin/pages/University/UniversityCountries';
import Layout from '../../../admin/components/Layout';
export default function UniversityCountriesPage() {
  return (
    <Layout>
      <UniversityCountries />
    </Layout>
  );
} 