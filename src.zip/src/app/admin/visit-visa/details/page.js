'use client';
import Layout from '../../components/Layout';
import VisaDetails from '../../pages/VisitVisa/VisaDetails';
export default function VisaDetailsPage() {
  return (
    <Layout>
      <VisaDetails />
    </Layout>
  );
} 