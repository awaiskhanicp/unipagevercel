'use client';
import Layout from '../../components/Layout';
import VisaCountryList from '../../pages/VisitVisa/VisaCountryList';
export default function VisaCountryListPage() {
  return (
    <Layout>
      <VisaCountryList />
    </Layout>
  );
} 