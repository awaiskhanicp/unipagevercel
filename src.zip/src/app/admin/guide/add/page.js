'use client';
import Layout from '../../components/Layout';
import AddGuide from '../../pages/Guide/AddGuide';
export default function AddGuidePage() {
  return (
    <Layout>
      <AddGuide />
    </Layout>
  );
} 