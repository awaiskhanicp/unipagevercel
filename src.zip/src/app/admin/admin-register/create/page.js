'use client';
import Layout from '../../components/Layout';
import CreateAdmin from '../../pages/AdminRegister/CreateAdmin';
export default function CreateAdminPage() {
  return (
    <Layout>
      <CreateAdmin />
    </Layout>
  );
} 