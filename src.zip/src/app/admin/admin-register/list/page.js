'use client';
import Layout from '../../components/Layout';
import AdminList from '../../pages/AdminRegister/AdminList';
export default function AdminListPage() {
  return (
    <Layout>
      <AdminList />
    </Layout>
  );
} 