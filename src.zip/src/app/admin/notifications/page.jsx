import Notifications from '../pages/Notifications';

export default function NotificationsPage() {
  return <Notifications />;
}