'use client';
import Layout from '../../components/Layout';
import AddCourse from '../../pages/Course/AddCourse';
export default function AddCoursePage() {
  return (
    <Layout>
      <AddCourse />
    </Layout>
  );
} 